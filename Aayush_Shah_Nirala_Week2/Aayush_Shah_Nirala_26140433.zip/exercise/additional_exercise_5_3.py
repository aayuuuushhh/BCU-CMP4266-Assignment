# 5.3 Write a program that prints three given numbers sorted from the smallest to the largest.

a =float(input("Enter first number: "))
b = float(input("Enter second number: "))
c = float(input("Enter third number: "))

if a<=b and a<=c:
    if b<=c:
        print(a, b, c)
    else:
        print(a, c, b)
elif b<= a and b<=c:
    if a<=c:
        print(b, a, c)
    else:
        print(b, c, a)
else:
    if a<=b:
        print(c, a, b)
    else:
        print(c, b, a)